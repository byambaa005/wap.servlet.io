package edu.mum.cs;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/calcSum")
public class ServletDemo extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {

        int a = Integer.parseInt(request.getParameter("first_sum"));
        int b = Integer.parseInt(request.getParameter("second_sum"));

        int c = Integer.parseInt(request.getParameter("first_mult"));
        int d = Integer.parseInt(request.getParameter("second_mult"));

        int sum = a + b;
        int mult = c * d;

        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<span>" + a + "+" + b + "=" + sum +"</span>" + "<br/>");
        out.println("<span>" + a + "*" + b + "=" + mult +"</span>");
        out.println("</body></html>");

        }
        catch (NumberFormatException e) {
            // log exception and / or notify user
            System.out.println("At least one invalid number in the given numbers: " + request.getParameter("first_sum") + ", " + request.getParameter("second_sum"));
            e.printStackTrace();
            // show an error message to the user somewhere in your frontend
            response.getWriter().println("<span>error</span>");
        }
    }
}

